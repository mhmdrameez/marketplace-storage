const DEV_HOSTS = new Set(["localhost", "127.0.0.1"]);
const STORAGE_KEYS = {
  lastClosed: "lastClosedDevTabs",
  autoGroup: "autoGroup",
  groupName: "groupName"
};

/** @param {string} url */
function isDevUrl(url) {
  try {
    const u = new URL(url);
    return DEV_HOSTS.has(u.hostname);
  } catch {
    return false;
  }
}

async function getSettings() {
  const { autoGroup = false, groupName = "Development" } = await chrome.storage.local.get({
    autoGroup: false,
    groupName: "Development"
  });
  return { autoGroup, groupName };
}

async function pushLastClosed(urls) {
  const { [STORAGE_KEYS.lastClosed]: existing = [] } = await chrome.storage.local.get({
    [STORAGE_KEYS.lastClosed]: []
  });

  const next = [...urls.filter(Boolean), ...existing].slice(0, 5);
  await chrome.storage.local.set({ [STORAGE_KEYS.lastClosed]: next });
}

async function closeTabs(tabIds) {
  if (!Array.isArray(tabIds) || tabIds.length === 0) return;

  const tabs = await chrome.tabs.query({});
  const idSet = new Set(tabIds);
  const urlsToStore = tabs
    .filter((t) => t.id != null && idSet.has(t.id) && isDevUrl(t.url || ""))
    .map((t) => t.url)
    .filter(Boolean);

  if (urlsToStore.length > 0) await pushLastClosed(urlsToStore);
  await chrome.tabs.remove(tabIds);
}

async function closeAllDevTabsInAllWindows() {
  const tabs = await chrome.tabs.query({});
  const devTabIds = tabs.filter((t) => isDevUrl(t.url || "")).map((t) => t.id).filter(Boolean);
  await closeTabs(devTabIds);
}

async function restoreLastClosed() {
  const { [STORAGE_KEYS.lastClosed]: existing = [] } = await chrome.storage.local.get({
    [STORAGE_KEYS.lastClosed]: []
  });
  if (!existing.length) return { ok: false };

  const [url, ...rest] = existing;
  await chrome.storage.local.set({ [STORAGE_KEYS.lastClosed]: rest });

  await chrome.tabs.create({ url });
  return { ok: true, url };
}

async function ensureDevelopmentGroupInWindow(windowId) {
  const { groupName } = await getSettings();
  const name = (groupName || "Development").trim() || "Development";
  const groups = await chrome.tabGroups.query({ windowId });
  const existing = groups.find((g) => (g.title || "").toLowerCase() === name.toLowerCase());
  if (existing) return existing.id;
  const groupId = await chrome.tabs.group({ tabIds: [], createProperties: { windowId } });
  await chrome.tabGroups.update(groupId, { title: name, color: "blue" });
  return groupId;
}

async function autoGroupIfEnabled(tabId, tabUrl, windowId) {
  if (!tabId || !tabUrl || windowId == null) return;
  if (!isDevUrl(tabUrl)) return;

  const { autoGroup } = await getSettings();
  if (!autoGroup) return;

  const groupId = await ensureDevelopmentGroupInWindow(windowId);
  await chrome.tabs.group({ tabIds: [tabId], groupId });
}

chrome.runtime.onMessage.addListener((msg, _sender, sendResponse) => {
  (async () => {
    if (msg?.type === "close-tabs") {
      await closeTabs(msg.tabIds || []);
      sendResponse({ ok: true });
      return;
    }
    if (msg?.type === "restore-last-closed") {
      const res = await restoreLastClosed();
      sendResponse(res);
      return;
    }
    sendResponse({ ok: false });
  })();
  return true;
});

chrome.commands.onCommand.addListener(async (command) => {
  if (command === "close-all-dev-tabs") {
    await closeAllDevTabsInAllWindows();
  }
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (!changeInfo.url) return;
  await autoGroupIfEnabled(tabId, changeInfo.url, tab.windowId);
});

