# Dev Tab Manager (Chrome Extension)

Manage development-related tabs (like `localhost` / `127.0.0.1`) directly from a fast popup: view, filter, pin, close, group, and restore.

## Features

- **Localhost detection**: lists open tabs whose URL host is `localhost` or `127.0.0.1`
- **Clean popup UI** (400×500 max): favicon, title, truncated URL, total count
- **Per-tab controls**: activate tab by clicking the row, pin/unpin, close
- **Bulk actions**:
  - **Close All** (with confirmation)
  - **Group Tabs** into a tab group named **Development** (blue)
- **Bonus**:
  - **Port pills** (shows `:3000`, `:5173`, etc. + counts)
  - **Restore**: reopens the last closed dev tab (keeps last 5 in `chrome.storage.local`)
  - **Keyboard shortcuts**:
    - Open popup: **Ctrl+Shift+L** (Mac: **Cmd+Shift+L**)
    - Close all dev tabs: **Ctrl+Shift+X** (Mac: **Cmd+Shift+X**)
  - **Auto-group** toggle: automatically groups newly-opened dev tabs

## Install (Developer Mode)

1. Open Chrome and go to `chrome://extensions`
2. Enable **Developer mode** (top right)
3. Click **Load unpacked**
4. Select this folder:
   - `Day-5`

## Usage

- Click the extension icon to open the popup.
- Use **Filter** to search by title or URL.
- Click a row to focus that tab.
- Use **Group Tabs** to put all dev tabs into the **Development** tab group.
- Use **Close All** to close all dev tabs (you’ll be asked to confirm).
- Use **Restore** to reopen the most recently closed dev tab (up to 5 stored).

## Permissions

- `tabs`: query, activate, pin/unpin, close tabs
- `tabGroups`: create/update the “Development” group
- `storage`: store last 5 closed dev URLs + the auto-group setting

## Project Structure

- `manifest.json` — Manifest V3 config + commands
- `popup.html` / `popup.css` / `popup.js` — UI and tab management
- `background.js` — keyboard shortcuts, auto-group, restore storage
- `icons/` — extension icons (16/48/128)

