const DEV_HOSTS = new Set(["localhost", "127.0.0.1"]);
const COMMON_DEV_PORTS = new Set(["3000", "5173", "8080", "5000", "8000"]);

/** @param {string} url */
function isDevUrl(url) {
  try {
    const u = new URL(url);
    return DEV_HOSTS.has(u.hostname);
  } catch {
    return false;
  }
}

/** @param {string} url */
function getPort(url) {
  try {
    const u = new URL(url);
    return u.port || (u.protocol === "https:" ? "443" : u.protocol === "http:" ? "80" : "");
  } catch {
    return "";
  }
}

/** @param {string} s */
function norm(s) {
  return (s || "").toLowerCase();
}

function byTitleThenId(a, b) {
  const at = (a.title || "").toLowerCase();
  const bt = (b.title || "").toLowerCase();
  if (at < bt) return -1;
  if (at > bt) return 1;
  return (a.id ?? 0) - (b.id ?? 0);
}

const els = {
  count: document.getElementById("count"),
  list: document.getElementById("list"),
  empty: document.getElementById("empty"),
  filter: document.getElementById("filter"),
  groupBtn: document.getElementById("groupBtn"),
  closeAllBtn: document.getElementById("closeAllBtn"),
  restoreBtn: document.getElementById("restoreBtn"),
  portsRow: document.getElementById("portsRow"),
  ports: document.getElementById("ports"),
  template: document.getElementById("rowTemplate"),
  autoGroup: document.getElementById("autoGroup"),
  showAll: document.getElementById("showAll"),
  groupName: document.getElementById("groupName")
};

/** @type {chrome.tabs.Tab[]} */
let devTabs = [];
/** @type {chrome.tabs.Tab[]} */
let allTabs = [];
/** @type {Set<number>} */
const selectedTabIds = new Set();

async function getSettings() {
  const { autoGroup = false, showAllTabs = false, groupName = "Development" } = await chrome.storage.local.get({
    autoGroup: false,
    showAllTabs: false,
    groupName: "Development"
  });
  return { autoGroup, showAllTabs, groupName };
}

async function setSettings(next) {
  await chrome.storage.local.set(next);
}

async function refresh() {
  const t0 = performance.now();

  allTabs = await chrome.tabs.query({});
  devTabs = allTabs.filter((t) => isDevUrl(t.url || ""));
  devTabs.sort(byTitleThenId);

  render();

  const dt = performance.now() - t0;
  // Keep any feedback subtle; but expose to console for perf verification.
  console.debug("[Dev Tab Manager] refreshed in", Math.round(dt), "ms");
}

function renderPorts() {
  const portCounts = new Map();
  for (const t of devTabs) {
    const p = getPort(t.url || "");
    if (!p) continue;
    portCounts.set(p, (portCounts.get(p) || 0) + 1);
  }

  const entries = Array.from(portCounts.entries()).sort((a, b) => Number(a[0]) - Number(b[0]));
  if (entries.length === 0) {
    els.portsRow.hidden = true;
    els.ports.textContent = "";
    return;
  }

  els.portsRow.hidden = false;
  els.ports.textContent = "";
  for (const [port, count] of entries) {
    const div = document.createElement("div");
    div.className = "pill";
    const tag = COMMON_DEV_PORTS.has(port) ? "dev" : "port";
    div.textContent = `:${port} (${count}) ${tag}`;
    els.ports.appendChild(div);
  }
}

function render() {
  const q = norm(els.filter.value);
  const base = els.showAll.checked ? allTabs : devTabs;
  const visible = q ? base.filter((t) => norm(t.title).includes(q) || norm(t.url).includes(q)) : base;

  els.count.textContent = String(visible.length);
  els.list.textContent = "";
  els.empty.hidden = visible.length !== 0;

  if (els.showAll.checked) {
    els.portsRow.hidden = true;
  } else {
    renderPorts();
  }

  const frag = document.createDocumentFragment();
  for (const tab of visible) {
    const node = els.template.content.firstElementChild.cloneNode(true);
    const select = node.querySelector(".select");
    const favicon = node.querySelector(".favicon");
    const title = node.querySelector(".row-title");
    const url = node.querySelector(".row-url");
    const closeBtn = node.querySelector(".close-btn");
    const pinBtn = node.querySelector(".pin-btn");

    if (tab.id != null) {
      select.checked = selectedTabIds.has(tab.id);
      select.addEventListener("click", (e) => e.stopPropagation());
      select.addEventListener("change", () => {
        if (select.checked) selectedTabIds.add(tab.id);
        else selectedTabIds.delete(tab.id);
      });
    } else {
      select.disabled = true;
    }

    favicon.src = tab.favIconUrl || "data:image/gif;base64,R0lGODlhAQABAAAAACw=";
    favicon.alt = "";
    title.textContent = tab.title || "(untitled)";
    url.textContent = tab.url || "";

    pinBtn.dataset.pinned = String(!!tab.pinned);
    pinBtn.addEventListener("click", async () => {
      if (!tab.id) return;
      await chrome.tabs.update(tab.id, { pinned: !tab.pinned });
      await refresh();
    });

    node.addEventListener("click", async (e) => {
      const target = /** @type {HTMLElement} */ (e.target);
      if (target.closest("button")) return;
      if (!tab.id) return;
      await chrome.tabs.update(tab.id, { active: true });
      if (tab.windowId != null) await chrome.windows.update(tab.windowId, { focused: true });
      window.close();
    });

    closeBtn.addEventListener("click", async () => {
      if (!tab.id) return;
      await chrome.runtime.sendMessage({ type: "close-tabs", tabIds: [tab.id] });
      selectedTabIds.delete(tab.id);
      await refresh();
    });

    frag.appendChild(node);
  }
  els.list.appendChild(frag);
}

async function groupAllDevTabs() {
  const selected = Array.from(selectedTabIds);
  const fallback = devTabs.map((t) => t.id).filter(Boolean);
  const tabIds = selected.length ? selected : fallback;
  if (tabIds.length === 0) return;

  const name = (els.groupName.value || "Development").trim() || "Development";
  const groupId = await chrome.tabs.group({ tabIds });
  await chrome.tabGroups.update(groupId, { title: name, color: "blue" });
  selectedTabIds.clear();
}

async function closeAllDevTabs() {
  const selected = Array.from(selectedTabIds);
  const baseIds = selected.length ? selected : devTabs.map((t) => t.id).filter(Boolean);
  if (baseIds.length === 0) return;
  const label = selected.length ? "selected tabs" : "dev tabs";
  const ok = confirm(
    `Close ${baseIds.length} ${label}? This can’t be undone (but you can restore the last few).`
  );
  if (!ok) return;
  await chrome.runtime.sendMessage({ type: "close-tabs", tabIds: baseIds });
  selectedTabIds.clear();
  await refresh();
}

async function restoreLastClosed() {
  const res = await chrome.runtime.sendMessage({ type: "restore-last-closed" });
  if (!res?.ok) {
    // subtle feedback: disable if nothing to restore
    return;
  }
  await refresh();
}

async function init() {
  const settings = await getSettings();
  els.autoGroup.checked = settings.autoGroup;
  els.showAll.checked = settings.showAllTabs;
  els.groupName.value = settings.groupName || "Development";

  els.autoGroup.addEventListener("change", async () => {
    await setSettings({ autoGroup: els.autoGroup.checked });
  });
  els.showAll.addEventListener("change", async () => {
    selectedTabIds.clear();
    await setSettings({ showAllTabs: els.showAll.checked });
    render();
  });
  els.groupName.addEventListener("input", async () => {
    const name = (els.groupName.value || "").trim();
    await setSettings({ groupName: name || "Development" });
  });

  els.filter.addEventListener("input", () => render());
  els.groupBtn.addEventListener("click", async () => {
    await groupAllDevTabs();
    await refresh();
  });
  els.closeAllBtn.addEventListener("click", closeAllDevTabs);
  els.restoreBtn.addEventListener("click", restoreLastClosed);

  await refresh();
}

init();

