$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Drawing

function New-IconPng([int]$size, [string]$outPath) {
  $bmp = New-Object System.Drawing.Bitmap $size, $size
  $g = [System.Drawing.Graphics]::FromImage($bmp)
  $g.SmoothingMode = [System.Drawing.Drawing2D.SmoothingMode]::AntiAlias
  $g.Clear([System.Drawing.Color]::Transparent)

  $bg = [System.Drawing.ColorTranslator]::FromHtml("#0b1220")
  $accent = [System.Drawing.ColorTranslator]::FromHtml("#3b82f6")
  $muted = [System.Drawing.ColorTranslator]::FromHtml("#dbeafe")

  $r = [int]([Math]::Round($size * 0.18))
  $pad = [int]([Math]::Round($size * 0.08))
  $rect = New-Object System.Drawing.Rectangle $pad, $pad, ($size - 2*$pad), ($size - 2*$pad)

  $path = New-Object System.Drawing.Drawing2D.GraphicsPath
  $d = 2*$r
  $path.AddArc($rect.X, $rect.Y, $d, $d, 180, 90) | Out-Null
  $path.AddArc($rect.Right-$d, $rect.Y, $d, $d, 270, 90) | Out-Null
  $path.AddArc($rect.Right-$d, $rect.Bottom-$d, $d, $d, 0, 90) | Out-Null
  $path.AddArc($rect.X, $rect.Bottom-$d, $d, $d, 90, 90) | Out-Null
  $path.CloseFigure() | Out-Null

  $brushBg = New-Object System.Drawing.SolidBrush $bg
  $g.FillPath($brushBg, $path)

  $penAccent = New-Object System.Drawing.Pen $accent, ([Math]::Max(1, [int]([Math]::Round($size * 0.06))))
  $g.DrawPath($penAccent, $path)

  # Draw a simple "tab" shape
  $tabW = [int]([Math]::Round($rect.Width * 0.62))
  $tabH = [int]([Math]::Round($rect.Height * 0.42))
  $tabX = $rect.X + [int]([Math]::Round($rect.Width * 0.19))
  $tabY = $rect.Y + [int]([Math]::Round($rect.Height * 0.22))
  $tabRect = New-Object System.Drawing.Rectangle $tabX, $tabY, $tabW, $tabH

  $tabPath = New-Object System.Drawing.Drawing2D.GraphicsPath
  $tr = [int]([Math]::Round($size * 0.09))
  $td = 2*$tr
  $tabPath.AddArc($tabRect.X, $tabRect.Y, $td, $td, 180, 90) | Out-Null
  $tabPath.AddArc($tabRect.Right-$td, $tabRect.Y, $td, $td, 270, 90) | Out-Null
  $tabPath.AddArc($tabRect.Right-$td, $tabRect.Bottom-$td, $td, $td, 0, 90) | Out-Null
  $tabPath.AddArc($tabRect.X, $tabRect.Bottom-$td, $td, $td, 90, 90) | Out-Null
  $tabPath.CloseFigure() | Out-Null

  $tabFill = New-Object System.Drawing.SolidBrush ([System.Drawing.ColorTranslator]::FromHtml("#111c33"))
  $g.FillPath($tabFill, $tabPath)
  $g.DrawPath((New-Object System.Drawing.Pen $muted, ([Math]::Max(1, [int]([Math]::Round($size * 0.03))))), $tabPath)

  # Code glyph "{}"
  $fontSize = [float]([Math]::Round($size * 0.34, 0))
  $font = New-Object System.Drawing.Font "Consolas", $fontSize, ([System.Drawing.FontStyle]::Bold), ([System.Drawing.GraphicsUnit]::Pixel)
  $sf = New-Object System.Drawing.StringFormat
  $sf.Alignment = [System.Drawing.StringAlignment]::Center
  $sf.LineAlignment = [System.Drawing.StringAlignment]::Center
  $glyphBrush = New-Object System.Drawing.SolidBrush $muted
  $center = New-Object System.Drawing.RectangleF ($rect.X), ($rect.Y + $rect.Height*0.55 - $fontSize*0.6), ($rect.Width), ($fontSize*1.3)
  $g.DrawString("{}", $font, $glyphBrush, $center, $sf)

  $dir = Split-Path -Parent $outPath
  if (!(Test-Path $dir)) { New-Item -ItemType Directory -Path $dir | Out-Null }
  $bmp.Save($outPath, [System.Drawing.Imaging.ImageFormat]::Png)

  $g.Dispose()
  $bmp.Dispose()
}

New-IconPng -size 16 -outPath (Join-Path $PSScriptRoot "..\\icons\\icon16.png")
New-IconPng -size 48 -outPath (Join-Path $PSScriptRoot "..\\icons\\icon48.png")
New-IconPng -size 128 -outPath (Join-Path $PSScriptRoot "..\\icons\\icon128.png")

Write-Host "Generated icons in ./icons"

